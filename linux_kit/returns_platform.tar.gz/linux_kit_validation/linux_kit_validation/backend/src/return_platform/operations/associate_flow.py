"""Associate-first conversational discovery, confirmation lock, and return handoff."""

from __future__ import annotations

import hashlib
import json
import uuid
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any, cast

from neo4j import AsyncDriver
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pymongo import AsyncMongoClient, ReturnDocument
from pymongo.errors import DuplicateKeyError

from return_platform.agents.contracts import (
    DiscoveryAssessmentRequest,
    DiscoveryCandidateInput,
    NormalizedReturnMethod,
    OrderSource,
    ProductPresence,
    ReturnItemInput,
    ReturnWorkflowAssessmentRequest,
)
from return_platform.agents.order_discovery import OrderDiscoveryAgent
from return_platform.agents.return_workflow import ReturnWorkflowAgent
from return_platform.configuration.return_configuration import (
    ReturnPlatformConfiguration,
    load_return_configuration,
)
from return_platform.configuration.settings import Settings
from return_platform.operations.models import ReturnCreateRequest, ReturnSessionView
from return_platform.operations.repository import OperationalRepository
from return_platform.operations.return_support.service import (
    CreateSupportWorkItemRequest,
    ReturnSupportService,
)


class AssociateModel(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class AnchorType(StrEnum):
    ORDER_NUMBER = "ORDER_NUMBER"
    CUSTOMER_ID = "CUSTOMER_ID"
    PHONE = "PHONE"
    EMAIL = "EMAIL"
    TRACKING_NUMBER = "TRACKING_NUMBER"
    SKU = "SKU"
    CUSTOMER_NAME = "CUSTOMER_NAME"
    PRODUCT_DESCRIPTION = "PRODUCT_DESCRIPTION"


class ConversationMessage(AssociateModel):
    id: str
    role: str
    content: str
    createdAt: datetime


class OrderLineCandidate(AssociateModel):
    orderLineId: str
    productId: str
    sku: str | None = None
    productDescription: str | None = None
    productType: str | None = None
    shippedQuantity: int | float | None = None


class OrderCandidate(AssociateModel):
    customerReference: str
    customerName: str | None = None
    orderReference: str
    sourceWebOrderNumber: str | None = None
    trilogieOrderNumber: str | None = None
    orderSource: OrderSource = OrderSource.UNKNOWN
    orderStatus: str | None = None
    sellWarehouseId: str | None = None
    shipFromWarehouseId: str | None = None
    shippingMethod: str | None = None
    confidenceMillionths: int = Field(ge=0, le=1_000_000)
    evidenceSource: str
    lines: list[OrderLineCandidate]


class DiscoveryLock(AssociateModel):
    customerReference: str
    orderReference: str
    sourceWebOrderNumber: str | None = None
    trilogieOrderNumber: str | None = None
    orderSource: OrderSource = OrderSource.UNKNOWN
    orderLineId: str
    productId: str
    lockDigest: str = Field(pattern=r"^[a-f0-9]{64}$")
    confirmedBy: str
    confirmedAt: datetime


class AssociateConversationView(AssociateModel):
    id: str
    status: str
    anchorType: AnchorType
    anchorValueMasked: str
    orderSource: OrderSource = OrderSource.UNKNOWN
    discoveryAssessment: dict[str, Any] | None = None
    messages: list[ConversationMessage]
    candidates: list[OrderCandidate]
    discoveryLock: DiscoveryLock | None = None
    returnDetails: dict[str, Any] | None = None
    returnSessionId: str | None = None
    discoverySnapshotId: str | None = None
    confirmationSnapshotId: str | None = None
    lastMessageSequence: int = Field(default=0, ge=0)
    nextQuestion: str | None = None
    version: int = Field(ge=0)
    createdAt: datetime
    updatedAt: datetime


class StartAssociateConversationRequest(AssociateModel):
    anchorType: AnchorType
    anchorValue: str = Field(min_length=2, max_length=256)

    @field_validator("anchorValue")
    @classmethod
    def normalize_anchor(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("anchorValue must not be blank")
        return normalized


class ConfirmDiscoveryRequest(AssociateModel):
    candidateIndex: int = Field(ge=0, le=99)
    orderLineId: str = Field(min_length=1, max_length=128)
    expectedVersion: int = Field(ge=0)


class ReturnDetailsRequest(AssociateModel):
    reasonCode: str = Field(min_length=1, max_length=64)
    returnQuantity: int = Field(ge=1, le=10_000)
    packageCount: int = Field(ge=1, le=10_000)
    shippingPathExpectation: NormalizedReturnMethod
    productPresence: ProductPresence = ProductPresence.PRESENT_AT_BRANCH
    branchReference: str | None = Field(default=None, max_length=128)
    associateReference: str | None = Field(default=None, max_length=128)
    pickupAssessment: dict[str, Any] | None = None
    attachmentIds: list[str] = Field(default_factory=list, max_length=100)
    notes: str | None = Field(default=None, max_length=2_000)
    expectedVersion: int = Field(ge=0)


def _now() -> datetime:
    return datetime.now(UTC)


def _digest(value: object) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
    ).hexdigest()


def _mask(value: str, anchor_type: AnchorType) -> str:
    if anchor_type not in {AnchorType.PHONE, AnchorType.EMAIL}:
        return value
    if len(value) <= 4:
        return "****"
    return f"{value[:2]}***{value[-2:]}"


def _nested(document: dict[str, Any], path: str) -> Any:
    value: Any = document
    for part in path.split("."):
        if not isinstance(value, dict):
            return None
        value = value.get(part)
    return value


def _first_nested(document: dict[str, Any], paths: tuple[str, ...]) -> Any:
    for path in paths:
        value = _nested(document, path)
        if value not in (None, ""):
            return value
    return None


def _first_line_value(line: dict[str, Any], paths: tuple[str, ...]) -> Any:
    for path in paths:
        value = _nested(line, path)
        if value not in (None, ""):
            return value
    return None


class AssociateConversationService:
    """Graph-first discovery with targeted source fallback and immutable confirmation locks."""

    def __init__(
        self,
        *,
        platform_client: AsyncMongoClient[dict[str, object]],
        source_client: AsyncMongoClient[dict[str, object]],
        graph: AsyncDriver,
        settings: Settings,
        repository: OperationalRepository,
        return_configuration: ReturnPlatformConfiguration | None = None,
    ) -> None:
        self._db = platform_client[settings.mongo_database]
        self._source = source_client[settings.source_mongo_database]
        self._graph = graph
        self._graph_database = settings.neo4j_database
        self._conversations = self._db["associate_conversations"]
        self._messages = self._db["associate_messages"]
        self._discovery_snapshots = self._db["discovery_snapshots"]
        self._return_request_snapshots = self._db["return_request_snapshots"]
        self._locks = self._db["discovery_locks"]
        self._repository = repository
        self._return_configuration = (
            return_configuration
            or load_return_configuration(settings.return_configuration_path).configuration
        )
        self._source_config = self._return_configuration.source_resolution
        self._order_discovery_agent = OrderDiscoveryAgent(self._return_configuration)
        self._return_workflow_agent = ReturnWorkflowAgent(self._return_configuration)
        self._return_support = ReturnSupportService(
            client=platform_client,
            settings=settings,
            configuration=self._return_configuration,
            operational_repository=repository,
        )

    async def ensure_indexes(self) -> None:
        await self._conversations.create_index([("createdAt", -1)])
        await self._conversations.create_index("status")
        await self._messages.create_index(
            [("conversationId", 1), ("sequence", 1)], unique=True
        )
        await self._messages.create_index([("conversationId", 1), ("createdAt", 1)])
        await self._discovery_snapshots.create_index("snapshotId", unique=True)
        await self._discovery_snapshots.create_index(
            [("conversationId", 1), ("snapshotType", 1), ("contentDigest", 1)],
            unique=True,
        )
        await self._return_request_snapshots.create_index(
            "requestSnapshotId", unique=True
        )
        await self._return_request_snapshots.create_index(
            [("sessionId", 1), ("contentDigest", 1)], unique=True
        )
        index_info = await self._locks.index_information()
        for obsolete_name in ("lockDigest_1", "orderReference_1_orderLineId_1"):
            if obsolete_name in index_info:
                await self._locks.drop_index(obsolete_name)
        await self._locks.create_index("lockDigest")
        await self._locks.create_index("expiresAt", expireAfterSeconds=0)
        await self._locks.create_index(
            [("lockKey", 1)],
            unique=True,
            partialFilterExpression={"status": "ACTIVE"},
            name="active_discovery_lock_unique",
        )

    @staticmethod
    def _view(document: dict[str, Any]) -> AssociateConversationView:
        return AssociateConversationView.model_validate(
            {
                "id": str(document["_id"]),
                **{key: value for key, value in document.items() if key not in ("_id", "anchorDigest", "createdBy")},
            }
        )

    @staticmethod
    def _message(role: str, content: str) -> dict[str, Any]:
        return {
            "id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "createdAt": _now(),
        }

    async def _persist_messages(
        self,
        conversation_id: str,
        *,
        starting_sequence: int,
        messages: list[dict[str, Any]],
    ) -> None:
        for offset, message in enumerate(messages):
            sequence = starting_sequence + offset
            document = {
                "_id": message["id"],
                "conversationId": conversation_id,
                "sequence": sequence,
                "speakerRole": message["role"],
                "messageText": message["content"],
                "attachmentIds": [],
                "extractedEvidence": [],
                "createdAt": message["createdAt"],
            }
            await self._messages.update_one(
                {"conversationId": conversation_id, "sequence": sequence},
                {"$setOnInsert": document},
                upsert=True,
            )

    async def _persist_discovery_snapshot(
        self,
        *,
        conversation_id: str,
        snapshot_type: str,
        payload: dict[str, Any],
        actor_id: str,
    ) -> str:
        content_digest = _digest(payload)
        snapshot_id = str(
            uuid.uuid5(
                uuid.NAMESPACE_URL,
                f"{conversation_id}:{snapshot_type}:{content_digest}",
            )
        )
        await self._discovery_snapshots.update_one(
            {
                "conversationId": conversation_id,
                "snapshotType": snapshot_type,
                "contentDigest": content_digest,
            },
            {
                "$setOnInsert": {
                    "_id": snapshot_id,
                    "snapshotId": snapshot_id,
                    "conversationId": conversation_id,
                    "snapshotType": snapshot_type,
                    "payload": payload,
                    "contentDigest": content_digest,
                    "schemaVersion": "1.0",
                    "createdBy": actor_id,
                    "createdAt": _now(),
                }
            },
            upsert=True,
        )
        return snapshot_id

    async def _persist_return_request_snapshot(
        self,
        *,
        session_id: str,
        conversation_id: str,
        payload: dict[str, Any],
        actor_id: str,
    ) -> tuple[str, str]:
        content_digest = _digest(payload)
        snapshot_id = str(
            uuid.uuid5(uuid.NAMESPACE_URL, f"{session_id}:{content_digest}")
        )
        await self._return_request_snapshots.update_one(
            {"sessionId": session_id, "contentDigest": content_digest},
            {
                "$setOnInsert": {
                    "_id": snapshot_id,
                    "requestSnapshotId": snapshot_id,
                    "sessionId": session_id,
                    "conversationId": conversation_id,
                    "payload": payload,
                    "contentDigest": content_digest,
                    "schemaVersion": "1.0",
                    "confirmedBy": actor_id,
                    "confirmedAt": _now(),
                    "submittedAt": _now(),
                }
            },
            upsert=True,
        )
        return snapshot_id, content_digest

    async def _graph_candidates(
        self, anchor_type: AnchorType, anchor_value: str
    ) -> list[OrderCandidate]:
        normalized_hash = hashlib.sha256(anchor_value.strip().lower().encode()).hexdigest()
        queries = {
            AnchorType.ORDER_NUMBER: (
                "MATCH (c:Customer)-[:PLACED_ORDER]->(o:SalesOrder {sales_order_number:$value}) "
                "OPTIONAL MATCH (o)-[:HAS_ORDER_LINE]->(l:OrderLine) "
                "OPTIONAL MATCH (l)-[:REFERENCES_PRODUCT]->(p:Product) "
                "RETURN c,o,collect({line:l,product:p}) AS lines LIMIT 20",
                anchor_value,
            ),
            AnchorType.CUSTOMER_ID: (
                "MATCH (c:Customer)-[:PLACED_ORDER]->(o:SalesOrder) "
                "WHERE c.customer_id=$value OR c.customer_key=$value "
                "OPTIONAL MATCH (o)-[:HAS_ORDER_LINE]->(l:OrderLine) "
                "OPTIONAL MATCH (l)-[:REFERENCES_PRODUCT]->(p:Product) "
                "RETURN c,o,collect({line:l,product:p}) AS lines LIMIT 20",
                anchor_value,
            ),
            AnchorType.PHONE: (
                "MATCH (c:Customer {phone_hash:$value})-[:PLACED_ORDER]->(o:SalesOrder) "
                "OPTIONAL MATCH (o)-[:HAS_ORDER_LINE]->(l:OrderLine) "
                "OPTIONAL MATCH (l)-[:REFERENCES_PRODUCT]->(p:Product) "
                "RETURN c,o,collect({line:l,product:p}) AS lines LIMIT 20",
                normalized_hash,
            ),
            AnchorType.EMAIL: (
                "MATCH (c:Customer {email_hash:$value})-[:PLACED_ORDER]->(o:SalesOrder) "
                "OPTIONAL MATCH (o)-[:HAS_ORDER_LINE]->(l:OrderLine) "
                "OPTIONAL MATCH (l)-[:REFERENCES_PRODUCT]->(p:Product) "
                "RETURN c,o,collect({line:l,product:p}) AS lines LIMIT 20",
                normalized_hash,
            ),
            AnchorType.TRACKING_NUMBER: (
                "MATCH (o:SalesOrder)-[:HAS_ORIGINAL_SHIPMENT]->"
                "(:Shipment {tracking_number:$value}) "
                "MATCH (c:Customer)-[:PLACED_ORDER]->(o) "
                "OPTIONAL MATCH (o)-[:HAS_ORDER_LINE]->(l:OrderLine) "
                "OPTIONAL MATCH (l)-[:REFERENCES_PRODUCT]->(p:Product) "
                "RETURN c,o,collect({line:l,product:p}) AS lines LIMIT 20",
                anchor_value,
            ),
            AnchorType.SKU: (
                "MATCH (o:SalesOrder)-[:HAS_ORDER_LINE]->(l:OrderLine) "
                "MATCH (l)-[:REFERENCES_PRODUCT]->(p:Product) "
                "WHERE p.sku=$value OR p.product_id=$value "
                "MATCH (c:Customer)-[:PLACED_ORDER]->(o) "
                "RETURN c,o,collect({line:l,product:p}) AS lines LIMIT 20",
                anchor_value,
            ),
        }
        query_definition = queries.get(anchor_type)
        if query_definition is None:
            return []
        query, query_value = query_definition
        records, _, _ = await self._graph.execute_query(
            query, value=query_value, database_=self._graph_database
        )
        candidates: list[OrderCandidate] = []
        for record in records:
            customer = dict(record["c"])
            order = dict(record["o"])
            lines: list[OrderLineCandidate] = []
            for entry in record["lines"]:
                line = dict(entry["line"]) if entry.get("line") is not None else {}
                product = dict(entry["product"]) if entry.get("product") is not None else {}
                if not line:
                    continue
                lines.append(
                    OrderLineCandidate(
                        orderLineId=str(line.get("order_line_key", "")),
                        productId=str(product.get("product_id", line.get("product_id", ""))),
                        sku=cast(str | None, product.get("sku")),
                        productDescription=cast(str | None, product.get("product_description")),
                        productType=cast(str | None, product.get("product_type")),
                        shippedQuantity=cast(int | float | None, line.get("shipped_quantity")),
                    )
                )
            if lines:
                candidates.append(
                    OrderCandidate(
                        customerReference=str(
                            customer.get("customer_id") or customer.get("customer_key")
                        ),
                        customerName=cast(str | None, customer.get("customer_name")),
                        orderReference=str(order.get("sales_order_number")),
                        sourceWebOrderNumber=cast(
                            str | None, order.get("source_web_order_number")
                        ),
                        trilogieOrderNumber=cast(
                            str | None,
                            order.get("trilogie_order_number")
                            or order.get("sales_order_number"),
                        ),
                        orderSource=(
                            OrderSource.FERGUSONHOME_WEB
                            if order.get("source_web_order_number")
                            else OrderSource.UNKNOWN
                        ),
                        orderStatus=cast(str | None, order.get("order_status")),
                        sellWarehouseId=cast(str | None, order.get("sell_warehouse_id")),
                        shipFromWarehouseId=cast(str | None, order.get("ship_from_warehouse_id")),
                        shippingMethod=cast(str | None, order.get("shipping_method")),
                        confidenceMillionths=980_000,
                        evidenceSource="NEO4J_GRAPH",
                        lines=lines,
                    )
                )
        return candidates

    async def _source_documents(
        self, anchor_type: AnchorType, anchor_value: str
    ) -> list[dict[str, Any]]:
        config = self._source_config
        sales = self._source[config.sales_invoice_collection]
        if anchor_type is AnchorType.ORDER_NUMBER:
            query: dict[str, Any] = {
                "$or": [
                    {path: anchor_value}
                    for path in dict.fromkeys(
                        (*config.order_number_paths, *config.web_order_paths)
                    )
                ]
            }
        elif anchor_type is AnchorType.CUSTOMER_ID:
            query = {
                "$or": [{path: anchor_value} for path in config.customer_id_paths]
            }
        elif anchor_type in {AnchorType.PHONE, AnchorType.EMAIL}:
            field = (
                config.phone_field
                if anchor_type is AnchorType.PHONE
                else config.email_field
            )
            customer = await self._source[config.customer_collection].find_one(
                {field: anchor_value}
            )
            customer_id = (
                _nested(cast(dict[str, Any], customer), config.customer_master_id_field)
                if customer
                else None
            )
            if customer_id is None:
                return []
            query = {
                "$or": [{path: customer_id} for path in config.customer_id_paths]
            }
        elif anchor_type is AnchorType.TRACKING_NUMBER:
            shipment = await self._source[config.shipment_collection].find_one(
                {config.tracking_field: anchor_value}
            )
            order_id = (
                _nested(cast(dict[str, Any], shipment), config.tracking_order_field)
                if shipment
                else None
            )
            if order_id is None:
                return []
            query = {
                "$or": [{path: order_id} for path in config.order_number_paths]
            }
        elif anchor_type is AnchorType.SKU:
            query = {
                "$or": [
                    {f"salesLines.lineData.{path}": anchor_value}
                    for path in dict.fromkeys(
                        (*config.sku_paths, *config.product_id_paths)
                    )
                ]
            }
        elif anchor_type is AnchorType.CUSTOMER_NAME:
            query = {
                "$or": [
                    {path: {"$regex": anchor_value, "$options": "i"}}
                    for path in config.customer_name_paths
                ]
            }
        else:
            query = {
                "$or": [
                    {
                        f"salesLines.lineData.{path}": {
                            "$regex": anchor_value,
                            "$options": "i",
                        }
                    }
                    for path in config.product_description_paths
                ]
            }
        cursor = sales.find(query).limit(20)
        return [cast(dict[str, Any], item) async for item in cursor]

    def _source_candidate(self, document: dict[str, Any]) -> OrderCandidate | None:
        config = self._source_config
        source_web_order = _first_nested(document, config.web_order_paths)
        trilogie_order = _first_nested(document, config.trilogie_order_paths)
        order_reference = trilogie_order or source_web_order or _first_nested(
            document, config.order_number_paths
        )
        customer_reference = _first_nested(document, config.customer_id_paths)
        if order_reference is None or customer_reference is None:
            return None
        lines: list[OrderLineCandidate] = []
        raw_lines = document.get("salesLines", [])
        if isinstance(raw_lines, list):
            for position, wrapper in enumerate(raw_lines):
                if not isinstance(wrapper, dict):
                    continue
                line = wrapper.get("lineData", wrapper)
                if not isinstance(line, dict):
                    continue
                product_id = _first_line_value(line, config.product_id_paths)
                if product_id is None:
                    continue
                line_id = _first_line_value(line, config.line_id_paths)
                lines.append(
                    OrderLineCandidate(
                        orderLineId=str(
                            line_id or f"{order_reference}:LINE:{position + 1}"
                        ),
                        productId=str(product_id),
                        sku=cast(
                            str | None, _first_line_value(line, config.sku_paths)
                        ),
                        productDescription=cast(
                            str | None,
                            _first_line_value(
                                line, config.product_description_paths
                            ),
                        ),
                        productType=cast(str | None, line.get("productType")),
                        shippedQuantity=cast(
                            int | float | None,
                            _first_line_value(line, config.shipped_quantity_paths),
                        ),
                    )
                )
        if not lines:
            return None
        return OrderCandidate(
            customerReference=str(customer_reference),
            customerName=cast(
                str | None, _first_nested(document, config.customer_name_paths)
            ),
            orderReference=str(order_reference),
            sourceWebOrderNumber=(
                str(source_web_order) if source_web_order is not None else None
            ),
            trilogieOrderNumber=(
                str(trilogie_order) if trilogie_order is not None else None
            ),
            orderSource=(
                OrderSource.FERGUSONHOME_WEB
                if source_web_order is not None
                else OrderSource.UNKNOWN
            ),
            orderStatus=cast(str | None, _nested(document, "salesHdrEventData.orderStatus")),
            sellWarehouseId=cast(str | None, _nested(document, "salesHdrEventData.sellWhseId")),
            shipFromWarehouseId=cast(
                str | None, _nested(document, "salesHdrEventData.shipFromWhseId")
            ),
            shippingMethod=cast(str | None, _nested(document, "salesHdr.shipping.shipViaCode")),
            confidenceMillionths=900_000,
            evidenceSource="SOURCE_MONGODB_TARGETED_FALLBACK",
            lines=lines,
        )

    async def _targeted_graph_upsert(self, candidates: list[OrderCandidate]) -> None:
        rows = [candidate.model_dump(mode="json") for candidate in candidates]
        if not rows:
            return
        await self._graph.execute_query(
            """
            UNWIND $rows AS row
            MERGE (c:Customer {customer_key: row.customerReference})
            SET c.customer_id=row.customerReference, c.customer_name=row.customerName,
                c.graph_synced_at=$syncedAt, c.sync_run_id=$syncRunId
            MERGE (o:SalesOrder {sales_order_number: row.orderReference})
            SET o.order_status=row.orderStatus, o.sell_warehouse_id=row.sellWarehouseId,
                o.ship_from_warehouse_id=row.shipFromWarehouseId,
                o.shipping_method=row.shippingMethod,
                o.source_web_order_number=row.sourceWebOrderNumber,
                o.trilogie_order_number=row.trilogieOrderNumber,
                o.graph_synced_at=$syncedAt, o.sync_run_id=$syncRunId
            MERGE (c)-[:PLACED_ORDER]->(o)
            FOREACH (_ IN CASE WHEN row.sourceWebOrderNumber IS NULL THEN [] ELSE [1] END |
                MERGE (w:WebOrder {web_order_number: row.sourceWebOrderNumber})
                SET w.graph_synced_at=$syncedAt, w.sync_run_id=$syncRunId
                MERGE (w)-[:RESOLVES_TO]->(o))
            FOREACH (line IN row.lines |
                MERGE (l:OrderLine {order_line_key: line.orderLineId})
                SET l.shipped_quantity=line.shippedQuantity, l.graph_synced_at=$syncedAt,
                    l.sync_run_id=$syncRunId
                MERGE (p:Product {product_id: line.productId})
                SET p.sku=line.sku, p.product_description=line.productDescription,
                    p.product_type=line.productType, p.graph_synced_at=$syncedAt,
                    p.sync_run_id=$syncRunId
                MERGE (o)-[:HAS_ORDER_LINE]->(l)
                MERGE (l)-[:REFERENCES_PRODUCT]->(p))
            """,
            rows=rows,
            syncedAt=_now().isoformat(),
            syncRunId=f"TARGETED:{uuid.uuid4()}",
            database_=self._graph_database,
        )

    def _assess_candidates(
        self,
        payload: StartAssociateConversationRequest,
        candidates: list[OrderCandidate],
    ) -> tuple[list[OrderCandidate], dict[str, Any], OrderSource]:
        evidence_key = {
            AnchorType.ORDER_NUMBER: "order_number",
            AnchorType.CUSTOMER_ID: "customer_id",
            AnchorType.PHONE: "phone_or_email",
            AnchorType.EMAIL: "phone_or_email",
            AnchorType.TRACKING_NUMBER: "tracking_number",
            AnchorType.SKU: "product_model",
            AnchorType.CUSTOMER_NAME: "customer_name",
            AnchorType.PRODUCT_DESCRIPTION: "product_model",
        }[payload.anchorType]
        candidate_by_id: dict[str, OrderCandidate] = {}
        inputs: list[DiscoveryCandidateInput] = []
        for candidate in candidates:
            candidate_id = f"{candidate.customerReference}:{candidate.orderReference}"
            candidate_by_id[candidate_id] = candidate
            inputs.append(
                DiscoveryCandidateInput(
                    candidateId=candidate_id,
                    orderReference=candidate.orderReference,
                    customerReference=candidate.customerReference,
                    orderSource=candidate.orderSource,
                    matchedAnchors=(payload.anchorType.value,),
                    evidenceReferences=(
                        f"{candidate.evidenceSource}:{candidate.orderReference}",
                    ),
                )
            )
        assessment = self._order_discovery_agent.assess(
            DiscoveryAssessmentRequest(
                suppliedEvidence={evidence_key: payload.anchorValue},
                candidates=tuple(inputs),
            )
        )
        ranked: list[OrderCandidate] = []
        for result in assessment.rankedCandidates:
            found_candidate = candidate_by_id.get(result.candidateId)
            if found_candidate is not None:
                ranked.append(
                    found_candidate.model_copy(
                        update={"confidenceMillionths": result.scoreMillionths}
                    )
                )
        return ranked, assessment.model_dump(mode="json"), assessment.orderSource

    async def start(
        self,
        payload: StartAssociateConversationRequest,
        *,
        actor_id: str,
    ) -> AssociateConversationView:
        await self.ensure_indexes()
        candidates = await self._graph_candidates(payload.anchorType, payload.anchorValue)
        if not candidates:
            documents = await self._source_documents(payload.anchorType, payload.anchorValue)
            candidates = [
                candidate
                for document in documents
                if (candidate := self._source_candidate(document))
            ]
            await self._targeted_graph_upsert(candidates)
        candidates, discovery_assessment, order_source = self._assess_candidates(
            payload, candidates
        )
        now = _now()
        if candidates:
            assistant_text = (
                f"I found {len(candidates)} source-backed candidate order(s). "
                "Review the evidence and confirm the customer, order, and exact order line."
            )
            status = "DISCOVERY_READY"
            next_question = (
                discovery_assessment.get("nextQuestion")
                or "Which order and order line should be returned?"
            )
        else:
            assistant_text = (
                "No order matched that evidence. Add a stronger anchor such as order "
                "number, customer ID, tracking number, or SKU."
            )
            status = "NO_MATCH"
            next_question = "What additional order evidence can you provide?"
        conversation_id = str(uuid.uuid4())
        initial_messages = [
            self._message(
                "ASSOCIATE",
                f"Start return lookup using {payload.anchorType.value}.",
            ),
            self._message("AI_ASSISTANT", assistant_text),
        ]
        document: dict[str, Any] = {
            "_id": conversation_id,
            "status": status,
            "anchorType": payload.anchorType.value,
            "anchorValueMasked": _mask(payload.anchorValue, payload.anchorType),
            "orderSource": order_source.value,
            "discoveryAssessment": discovery_assessment,
            "anchorDigest": _digest(
                {"type": payload.anchorType.value, "value": payload.anchorValue}
            ),
            "messages": initial_messages,
            "lastMessageSequence": len(initial_messages),
            "candidates": [candidate.model_dump(mode="json") for candidate in candidates],
            "discoveryLock": None,
            "returnDetails": None,
            "returnSessionId": None,
            "nextQuestion": next_question,
            "version": 0,
            "createdBy": actor_id,
            "createdAt": now,
            "updatedAt": now,
        }
        await self._conversations.insert_one(document)
        await self._persist_messages(
            conversation_id, starting_sequence=1, messages=initial_messages
        )
        discovery_snapshot_id = await self._persist_discovery_snapshot(
            conversation_id=conversation_id,
            snapshot_type="DISCOVERY_CANDIDATES",
            payload={
                "anchorType": payload.anchorType.value,
                "anchorValueMasked": document["anchorValueMasked"],
                "orderSource": order_source.value,
                "candidates": document["candidates"],
                "assessment": discovery_assessment,
            },
            actor_id=actor_id,
        )
        await self._conversations.update_one(
            {"_id": conversation_id},
            {"$set": {"discoverySnapshotId": discovery_snapshot_id}},
        )
        document["discoverySnapshotId"] = discovery_snapshot_id
        decision = discovery_assessment.get("decision")
        if isinstance(decision, dict):
            await self._repository.persist_agent_decision(
                aggregate_id=str(document["_id"]),
                session_id=None,
                decision=decision,
                decision_key=f"discovery:{document['anchorDigest']}",
                actor_id=actor_id,
            )
        return self._view(document)

    async def list(self, limit: int = 100) -> list[AssociateConversationView]:
        documents = await self._conversations.find({}).sort("createdAt", -1).limit(limit).to_list()
        return [self._view(document) for document in documents]

    async def get(self, conversation_id: str) -> AssociateConversationView | None:
        document = await self._conversations.find_one({"_id": conversation_id})
        return None if document is None else self._view(document)

    async def confirm(
        self,
        conversation_id: str,
        payload: ConfirmDiscoveryRequest,
        *,
        actor_id: str,
    ) -> AssociateConversationView:
        conversation = await self.get(conversation_id)
        if conversation is None:
            raise KeyError(conversation_id)
        if conversation.version != payload.expectedVersion:
            raise RuntimeError("Conversation version conflict")
        if conversation.discoveryLock is not None:
            return conversation
        if payload.candidateIndex >= len(conversation.candidates):
            raise ValueError("candidateIndex is out of range")
        candidate = conversation.candidates[payload.candidateIndex]
        line = next(
            (item for item in candidate.lines if item.orderLineId == payload.orderLineId), None
        )
        if line is None:
            raise ValueError("orderLineId does not belong to the selected order")
        lock_payload = {
            "customerReference": candidate.customerReference,
            "orderReference": candidate.orderReference,
            "sourceWebOrderNumber": candidate.sourceWebOrderNumber,
            "trilogieOrderNumber": candidate.trilogieOrderNumber,
            "orderSource": candidate.orderSource,
            "orderLineId": line.orderLineId,
            "productId": line.productId,
        }
        lock_key = f"{candidate.orderReference}:{line.orderLineId}"
        lock = DiscoveryLock(
            **lock_payload,
            lockDigest=_digest(lock_payload),
            confirmedBy=actor_id,
            confirmedAt=_now(),
        )
        try:
            await self._locks.insert_one(
                {
                    "_id": str(uuid.uuid4()),
                    **lock.model_dump(mode="json"),
                    "conversationId": conversation_id,
                    "lockKey": lock_key,
                    "status": "ACTIVE",
                    "expiresAt": _now() + timedelta(minutes=30),
                    "returnSessionId": None,
                }
            )
        except DuplicateKeyError as error:
            existing = await self._locks.find_one({"lockKey": lock_key, "status": "ACTIVE"})
            if existing is None or existing.get("conversationId") != conversation_id:
                raise RuntimeError(
                    "Order line is already locked by another return session"
                ) from error
        confirmation_messages = [
            self._message(
                "ASSOCIATE",
                f"Confirmed {candidate.orderReference} / {line.orderLineId}.",
            ),
            self._message(
                "AI_ASSISTANT",
                "Discovery is locked. Provide reason, quantity, package count, "
                "shipping path, and optional notes.",
            ),
        ]
        updated = await self._conversations.find_one_and_update(
            {"_id": conversation_id, "version": payload.expectedVersion, "discoveryLock": None},
            {
                "$set": {
                    "status": "DETAILS_REQUIRED",
                    "orderSource": (
                        candidate.orderSource.value
                        if candidate.orderSource is not OrderSource.UNKNOWN
                        else conversation.orderSource.value
                    ),
                    "discoveryLock": lock.model_dump(mode="json"),
                    "nextQuestion": "Why is the item being returned?",
                    "updatedAt": _now(),
                },
                "$push": {"messages": {"$each": confirmation_messages}},
                "$inc": {
                    "version": 1,
                    "lastMessageSequence": len(confirmation_messages),
                },
            },
            return_document=ReturnDocument.AFTER,
        )
        if updated is None:
            raise RuntimeError("Conversation version conflict")
        ending_sequence = int(str(updated.get("lastMessageSequence", 0)))
        await self._persist_messages(
            conversation_id,
            starting_sequence=ending_sequence - len(confirmation_messages) + 1,
            messages=confirmation_messages,
        )
        confirmation_snapshot_id = await self._persist_discovery_snapshot(
            conversation_id=conversation_id,
            snapshot_type="DISCOVERY_CONFIRMED",
            payload={
                "lock": lock.model_dump(mode="json"),
                "candidate": candidate.model_dump(mode="json"),
                "line": line.model_dump(mode="json"),
            },
            actor_id=actor_id,
        )
        await self._conversations.update_one(
            {"_id": conversation_id},
            {"$set": {"confirmationSnapshotId": confirmation_snapshot_id}},
        )
        updated["confirmationSnapshotId"] = confirmation_snapshot_id
        return self._view(cast(dict[str, Any], updated))

    async def submit_details(
        self,
        conversation_id: str,
        payload: ReturnDetailsRequest,
        *,
        actor_id: str,
        correlation_id: str,
    ) -> tuple[AssociateConversationView, ReturnSessionView]:
        conversation = await self.get(conversation_id)
        if conversation is None:
            raise KeyError(conversation_id)
        if conversation.version != payload.expectedVersion:
            raise RuntimeError("Conversation version conflict")
        lock = conversation.discoveryLock
        if lock is None:
            raise ValueError("Discovery must be confirmed before collecting return details")
        selected_line = next(
            (
                item
                for candidate in conversation.candidates
                if candidate.orderReference == lock.orderReference
                for item in candidate.lines
                if item.orderLineId == lock.orderLineId
            ),
            None,
        )
        if selected_line is None:
            raise RuntimeError("Locked order line is absent from the sealed discovery context")
        if (
            selected_line.shippedQuantity is not None
            and payload.returnQuantity > selected_line.shippedQuantity
        ):
            raise ValueError("Return quantity exceeds the shipped quantity for the locked line")
        selected_candidate = next(
            (
                candidate
                for candidate in conversation.candidates
                if candidate.orderReference == lock.orderReference
            ),
            None,
        )
        if selected_candidate is None:
            raise RuntimeError("Locked order candidate is absent from discovery context")
        order_source = (
            selected_candidate.orderSource
            if selected_candidate.orderSource is not OrderSource.UNKNOWN
            else conversation.orderSource
        )
        workflow_assessment = self._return_workflow_agent.assess(
            ReturnWorkflowAssessmentRequest(
                sessionId=conversation_id,
                orderSource=order_source,
                productPresence=payload.productPresence,
                proposedReturnMethod=payload.shippingPathExpectation,
                branchId=payload.branchReference,
                associateId=payload.associateReference or actor_id,
                items=(
                    ReturnItemInput(
                        orderLineId=lock.orderLineId,
                        productId=lock.productId,
                        requestedQuantity=payload.returnQuantity,
                        shippedQuantity=(
                            int(selected_line.shippedQuantity)
                            if selected_line.shippedQuantity is not None
                            else None
                        ),
                        reasonCode=payload.reasonCode,
                        attachmentIds=tuple(payload.attachmentIds),
                    ),
                ),
                pickupAssessment=payload.pickupAssessment,
            )
        )
        if not workflow_assessment.complete:
            raise ValueError(
                "Return details are incomplete: " + ", ".join(workflow_assessment.missingFields)
            )
        details = {
            **payload.model_dump(mode="json", exclude={"expectedVersion"}),
            "supportDraft": workflow_assessment.supportDraft,
            "agentDecision": workflow_assessment.decision.model_dump(mode="json"),
        }
        session = await self._repository.create_return(
            ReturnCreateRequest(
                customerReference=lock.customerReference,
                orderReference=lock.orderReference,
                itemReferences=[lock.orderLineId],
                productReferences=[lock.productId],
                processingWarehouseReference=next(
                    (
                        candidate.sellWarehouseId or candidate.shipFromWarehouseId
                        for candidate in conversation.candidates
                        if candidate.orderReference == lock.orderReference
                    ),
                    None,
                ),
                productType=selected_line.productType,
                reasonCode=payload.reasonCode,
                returnQuantity=payload.returnQuantity,
                packageCount=payload.packageCount,
                shippingPathExpectation=workflow_assessment.recommendedReturnMethod.value,
                orderSource=order_source.value,
                sourceWebOrderNumber=selected_candidate.sourceWebOrderNumber,
                trilogieOrderNumber=(
                    selected_candidate.trilogieOrderNumber or lock.orderReference
                ),
                productPresence=payload.productPresence.value,
                branchReference=payload.branchReference,
                associateReference=payload.associateReference or actor_id,
                pickupAssessment=payload.pickupAssessment,
                assumptionSetVersion=self._return_configuration.assumption_set_version,
                notes=payload.notes,
                channel="ASSOCIATE",
                idempotencyKey=f"associate:{conversation_id}:{lock.lockDigest}",
            ),
            correlation_id=correlation_id,
            actor_id=actor_id,
        )
        await self._repository.persist_return_intake_records(
            session_id=session.id,
            order_line_id=lock.orderLineId,
            product_id=lock.productId,
            reason_code=payload.reasonCode,
            requested_quantity=payload.returnQuantity,
            approved_method=workflow_assessment.recommendedReturnMethod.value,
            product_presence=payload.productPresence.value,
            package_count=payload.packageCount,
            pickup_assessment=payload.pickupAssessment,
            attachment_ids=payload.attachmentIds,
            actor_id=actor_id,
        )
        await self._repository.persist_agent_decision(
            aggregate_id=session.id,
            session_id=session.id,
            decision=workflow_assessment.decision.model_dump(mode="json"),
            decision_key=f"return-workflow:{conversation_id}:v{payload.expectedVersion}",
            actor_id=actor_id,
        )
        request_snapshot_id, snapshot_digest = await self._persist_return_request_snapshot(
            session_id=session.id,
            conversation_id=conversation_id,
            payload={
                "discoveryLock": lock.model_dump(mode="json"),
                "returnDetails": details,
                "returnSession": session.model_dump(mode="json"),
            },
            actor_id=actor_id,
        )
        await self._repository.update_return(
            session.id,
            {"returnRequestSnapshotId": request_snapshot_id},
        )
        await self._return_support.create_work_item(
            CreateSupportWorkItemRequest(
                sessionId=session.id,
                subject=f"Return request for order {lock.orderReference}",
                supportDraft=workflow_assessment.supportDraft,
                requestSnapshotDigest=snapshot_digest,
                idempotencyKey=f"support:{session.id}:{snapshot_digest}",
            ),
            actor_id=actor_id,
            correlation_id=correlation_id,
        )
        session = await self._repository.get_return(session.id) or session
        await self._locks.update_one(
            {"lockDigest": lock.lockDigest, "conversationId": conversation_id, "status": "ACTIVE"},
            {
                "$set": {
                    "returnSessionId": session.id,
                    "expiresAt": _now() + timedelta(days=7),
                }
            },
        )
        submission_messages = [
            self._message("ASSOCIATE", "Confirmed return handling details."),
            self._message(
                "AI_ASSISTANT",
                f"Return session {session.id} was created and handed to "
                "Return Support processing.",
            ),
        ]
        updated = await self._conversations.find_one_and_update(
            {"_id": conversation_id, "version": payload.expectedVersion},
            {
                "$set": {
                    "status": "SUBMITTED",
                    "returnDetails": details,
                    "returnSessionId": session.id,
                    "nextQuestion": None,
                    "updatedAt": _now(),
                },
                "$push": {"messages": {"$each": submission_messages}},
                "$inc": {
                    "version": 1,
                    "lastMessageSequence": len(submission_messages),
                },
            },
            return_document=ReturnDocument.AFTER,
        )
        if updated is None:
            raise RuntimeError("Conversation version conflict")
        ending_sequence = int(str(updated.get("lastMessageSequence", 0)))
        await self._persist_messages(
            conversation_id,
            starting_sequence=ending_sequence - len(submission_messages) + 1,
            messages=submission_messages,
        )
        return self._view(cast(dict[str, Any], updated)), session
