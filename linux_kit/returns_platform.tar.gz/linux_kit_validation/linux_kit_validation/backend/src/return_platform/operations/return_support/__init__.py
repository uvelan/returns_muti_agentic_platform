"""Return Support integration boundary."""
